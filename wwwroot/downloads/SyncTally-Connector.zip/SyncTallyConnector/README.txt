SyncTally Connector (Tally Sync Config)
=====================================
Requires: Windows 10/11 with .NET Framework 4.8 (already installed on current Windows).

1. Unzip this whole folder anywhere (keep all files together).
2. Open "Tally Sync Config.exe.config" in Notepad and replace the DbConnectionString placeholders
   (YOUR_DB_SERVER / YOUR_DB_USER / YOUR_DB_PASSWORD) with the details provided by SyncTally.
3. Double-click "Tally Sync Config.exe" and sign in.
4. In Tally Prime: F1 (Help) > Settings > Connectivity > Client/Server configuration. Set Tally to act as Both, port 9000.

The connector only makes outbound connections. No remote desktop is needed.
